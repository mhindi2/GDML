pyside-rcc -py3 -o ../GDMLResources.py GDML.qrc

